<?php
	abstract class pageSetup{
		protected $defaultpage = 'home';
		public $page;
		public $environment = 'dev';
		public $filepath;
		protected $ext = '.php';
		protected $defaultfile = 'home.php';
		function __construct($page,$pagerel){
			//Get the pseudo-environment from the server
			if(getenv('EB_ENVIRONMENT') != FALSE){
				$this->environment = getenv('EB_ENVIRONMENT');
			}
			
			//Where the page is being called from, on a bigger site this wouldn't be a good idea
			$this->pagerel = $pagerel;
			$this->page = trim($page,"/");
			
			//Ensure that the page exists
			$this->filepath = "{$this->pagerel}/pages/{$this->page}.php";
			
			//If it doesn't then serve up the default page
			//Keep in mind that the apache config already filters out pages that don't exist
			if(!file_exists($this->filepath) || $this->page == ''){
				$this->page = $this->defaultpage;
				$this->filepath = "{$this->pagerel}/pages/{$this->page}.php";
			}
		}
	}
	
	//Setup our menu based on the pages that exist in the /pages directory only ever called from a static page
	class menuSetUp extends pageSetup{
		public $menuid = "menu";
		public $files;
		public $printmenu;
		
		function __construct($page,$pagerel){
			parent::__construct($page,$pagerel);
			$this->files = scandir('./pages/');
			
			//Remove the entries for the directories and the homepage
			array_splice($this->files,0,2);
			array_splice($this->files,array_search($this->defaultfile,$this->files),1);
			
			//Prepend the homepage to the front of the list
			array_unshift($this->files,$this->defaultfile);
    		foreach ($this->files as $value) {
				
    			//Remove the fileextension
    			$hrefval = preg_replace('/\..{1,4}$/','', $value);
    			$class = '';
    			
    			//If the page selected matches the page that's currently selected then add a class to indicate that in the menu
    			if($hrefval == $this->page){
	    			$class = 'selected';
    			}
    			//Uppercase the menu and replace spaces with underscores 
    			$printvalue = strtoupper(preg_replace(array('/\..{1,4}$/','/_/'),array('',' '), $value));
				$this->printmenu[] = "<li><a href='$hrefval' id='link_$hrefval' class='$class'>$printvalue</a></li>";
			}
		}
		public function printMenu(){
			print "<ul id='{$this->menuid}'>".implode($this->printmenu)."</ul>";			
		}
	}
	
	//Prints the main page contents
	class pageOutput extends PageSetup{
		public $pass;
		function __construct($page,$pagerel,$passin){
			parent::__construct($page,$pagerel);
			$this->pass = $passin;
		}
		function requireContents(){
			require($this->filepath);
		}
	}
	
	//Print the html footer
	class htmlFooter extends PageSetup{
		public $htmlfooter;
		function __construct($page,$pagerel){
			parent::__construct($page,$pagerel);
			switch($this->page){
			    case "contact":
			        $this->htmlfooter = "<button type='submit' id='sendmail' class='mail'>SEND MESSAGE</button>";
			        break;
				/*
				case "cv":
					$this->htmlfooter = "<button type='submit'>CV DOWNLOAD</button><button type='submit'>CV VIEW</button>";
					break;
				*/
				default:
	       			$this->htmlfooter = "<button type='submit'></button>";
					break;
			}
		}
		function printFooter(){
			print($this->htmlfooter);
		}
	}
?>