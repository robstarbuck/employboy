<?php
	require_once('./switchboard.php');
	require_once('./actions.php');
	$action = new execute($_GET['curpage']);
	$output = new pageOutput($_GET['curpage'],'..',$action->exeobj);
	$output->requireContents();
?>