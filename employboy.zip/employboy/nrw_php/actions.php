<?php
	//Supporting functions for the contact class, can also be called on it's own
	class contact_functions{
		
		//Elements to be included
		public $elements = array('name','email','text');
		
		//Regex for elements
		public $elements_regex = array(
			'name' => '/^[a-zA-Z0-9\.\_\- ]{2,30}$/',
			'email' => '/^[a-zA-Z0-9\.\_\-]+@[a-zA-Z0-9\.\-]+\.[a-zA-Z]{2,4}$/',
			'text' => '/^[a-zA-Z0-9 \n\.\,\@\&\£\$\=\-\'\"\?\!]{15,250}.{1}$/'
		);
		
		//Error messages for element
		public $spec_array = array(
			'name' => 'Must be between 2 and 30 characters.',
			'email' => 'Addresses given must be valid.',
			'text' => 'Must be between 15 and 250 characters'
		);
		
		private $employboy_email = array(
			'email' => "employboy@gmail.com",
			'name' => "Employboy"
		);
		
		//Extra elements
		public $checkbox = 'check_cc';
		
		//Function that validates the element
		public function validate_input($type,$value){
			if(preg_match($this->elements_regex[$type],$value)){
				return 1;
			}
			return 0;
		}
		
		//Returns an error message from the array 
		public function get_error($type){
			if(array_key_exists($type,$this->spec_array)){
				return $this->spec_array[$type];
			}
			return '';
		}
		
		//Print the results of message send request
		public function print_sendresults($blnresult,$error){
			if($error){
				print("<div id='contact_alert' class='alert'>An error has occured, please try later.</div>");
			}
			else if($blnresult){
				print("<div id='contact_alert' class='notify'>Thank you, your message has been sent.</div>");
			}
			else{
				print("<div id='contact_alert' class='alert'>Please check the fields above before sending again.</div>");
			}
		}
		
		//Send message function
		public function sendmessage($sendarray,$pagerel){
			//pagerel tells us where the script is being called from in order to locate the phpmailer file
			//Class to include
			require_once($pagerel.'/nrw_php/PHPMailer_v5.1/class.phpmailer.php');
			
			$mail = new PHPMailer();
			
			//$employboy_address
			
			$mail->IsSMTP(); // telling the class to use SMTP
			                                           // 1 = errors and messages
			$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
			                                           // 2 = messages only
			$mail->SMTPAuth   = true;                  // enable SMTP authentication
			$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
			$mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
			$mail->Port       = 465;                   // set the SMTP port for the GMAIL server
			$mail->Username   = "employboy@gmail.com"; // GMAIL username
			$mail->Password   = "boyploy996633";       // GMAIL password
			
			$mail->SetFrom($sendarray['email'],$sendarray['name']);
			
			$mail->AddReplyTo($sendarray['email'],$sendarray['name']);
			
			$mail->Subject    = "Message to Employboy.com";
			
			$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
			
			$mail->MsgHTML($sendarray['text']);
			
			$address = "employboy@gmail.com";
			
			$mail->AddAddress($this->employboy_email['email'],$this->employboy_email['name']);
			
			if(array_key_exists($this->checkbox,$sendarray)){
				$mail->AddAddress($sendarray['email'],$sendarray['name']);
			}
			if($mail->Send()){
				return true;
			}
			return false;
		}
	}

	//contact class
	class contact{
		public $valid = array();
		public $defined = 0;
		public $post_value = array();
		public $error_array = array();
		public $sent = 0;
		public $senderror = 0;
		function __construct(){
			$this->contact_functions = new contact_functions();
			
			//Determine whether or not the form as been sent
			if(isset($_POST['pagetype'])){
				$this->defined = 1;
				
				//Loop through the required elements
				foreach($this->contact_functions->elements as $key=>$value){
					
					//ensure the element made it through with the form
					if(isset($_POST[$value])){
						
						//Replace double quotes for singles so as to avoid any difficulties
						$this->post_value[$value] = str_replace('"',"'",trim($_POST[$value]));

						//Validate the fields against the relative regex
						if($this->contact_functions->validate_input($value,$this->post_value[$value])){
							$this->valid[$value] = 1;
						}
						//If it's invalid then populate the spec array with the field as the key						
						else{
							$this->error_array[$value] = $this->contact_functions->spec_array[$value];
							$this->valid[$value] = 0;
						}
					}
				}
			}
			else{
				$this->defined = 0;
			}
			
			//If the form was sent and has no invalid fields then send the form
			if($this->defined && !in_array(0,$this->valid)){
				
				//If the checkbox was passed along 
				if(isset($_POST[$this->contact_functions->checkbox])){
					$this->post_value[$this->contact_functions->checkbox] = 1;
				}
				
				//Send the message and pass in where the request is being called from
				if(!$this->contact_functions->sendmessage($this->post_value,'.')){
					$this->senderror = 1;
				}
				else{
					$this->post_value = array();
					$this->sent = 1;
				}
			}
		}
		
		//Has the form been sent
		public function get_defined(){
			return $this->defined;			
		}
		
		//Print the results of the send
		public function print_success(){
			if($this->defined){
				$this->contact_functions->print_sendresults($this->sent,$this->senderror);
			}
		}
		
		//used by the static page, passes through the pages elements
		public function get_passed_val($elem){
			
			//if the element doesn't exist return an empty string
			if(in_array($elem,$this->contact_functions->elements)){
				if(isset($this->post_value[$elem])){
					return $this->post_value[$elem];
				}
				else{
					return '';
				}
			}
			//If we try to return an element that doesn't exist - kick off
			else{
				die($elem." is not defined");
			}
		}
		
		//Print the error
		public function print_error_val($elem){
			if(array_key_exists($elem,$this->error_array)){
				print "<span class='error' id='".$elem."_error'>".$this->error_array[$elem]."</span>";
			}
			else{
				print "";
			}
		}
	}
	
	//Used for static pages
	class execute{
		public $exeobj;
		function __construct($page){
			
			//Determine whether or not the class exists in page
			if(class_exists($page)){
				
				//Instantiate
				$this->exeobj = new $page();
			}
		}
	}
?>