<?php
	require_once('./actions.php');
	$valid = $_GET['valid'];
	$success = 0;
	$error = 0;
	$post_value = array();
	$contactfunctions = new contact_functions();
	//print_r($_POST);
	if($valid == 'true'){
		if(isset($_POST['pagetype'])){
			foreach($contactfunctions->elements as $key=>$value){
				if(!isset($_POST[$value])){
					$valid = 0;					
					break;
				}
				else{
					$tvalue = trim($_POST[$value]);
					if(!$contactfunctions->validate_input($value,$tvalue)){
						$valid = 0;
						break;
					}
					else{
						$post_value[$value] = $tvalue;
					}		
				}
			}
		}
		if(isset($_POST[$contactfunctions->checkbox])){
			$post_value[$contactfunctions->checkbox] = 1;
		}
		$success = $contactfunctions->sendmessage($post_value,'..');
		$error = !$success;
	}
	//print('{"result":'.$success.',"message":"'.$contactfunctions->print_sendresults($success,$error).'"}');
?>
{"result":"<?php print($success)?>","divmessage":"<?php print($contactfunctions->print_sendresults($success,$error))?>"}