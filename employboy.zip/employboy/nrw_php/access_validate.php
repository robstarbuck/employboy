<?php
	require_once('./actions.php');
	$errormessage = '';
	$pagename = $_GET['curpage'];
	$funccall = $pagename.'_functions';
	$validfunctions = new $funccall;
	$results = $validfunctions->validate_input($_POST['name'],trim($_POST['value']));
	if(!$results){
		$errormessage = $validfunctions->get_error($_POST['name']);
	}
	print('{"valid":'.$results.',"errormessage":"'.$errormessage.'"}');
?>