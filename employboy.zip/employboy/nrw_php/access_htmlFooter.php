<?php
	require_once('./switchboard.php');
	$footeroutput = new htmlFooter($_GET['curpage'],'..');
	$footeroutput->printFooter();
?>