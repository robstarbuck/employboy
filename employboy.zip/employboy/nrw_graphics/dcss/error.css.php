
/* JAVASCRIPT DISABLED */

/* General */

* {
	font-family: verdana;
	font-size: 8pt;
	color:<?php print($colors->base) ?>;
	white-space:normal;
}
body{
	overflow:hidden;
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bg.png);
	background-repeat:repeat;
	padding:1.5em;
	margin:0;
}

img{
	display:block;
}
#errorcen
{
	width:450px;height:25em;
	left:50%;top:50%;
	margin:-12.5em 0 0 -200px;
	position:fixed;
}
* #errorcen{position:absolute;}

div#box{
	position:fixed;
	width:450px;
}
div#top{
	background-image:url(<?php print($colors->imagedirectory)?>_inv_rnd_tp.png);
	height:17px;
}
div#btm{
	background-image:url(<?php print($colors->imagedirectory)?>_inv_rnd_bt.png);
	height:17px;
}
div#head{
	height:95px;
	margin:0;
	padding:0;
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_fg.png);
	position:relative;
}
div#title{
	background-image:url(<?php print($colors->imagedirectory)?>_inv_ebtle.png);
	background-position:30px bottom;
	background-repeat:no-repeat;
	height:65px;
	position:relative;
	margin:0 0 1em;
}
div#menuhold{
	width:390px;
}
ul#menu{
	font-size:110%;
	font-weight:bold;
	display:block;
	padding:0;
	margin:0;
	line-height:2em;
}
ul#menu li{
	margin:0 1em 0 0;
	padding:0;
	display:inline;
}
ul#menu a{
	text-decoration:none;
	outline:none;
}

div#menuhold #underline{
	height:3px;
	background-color:<?php print($colors->base) ?>;
	font-size:0;
}

div#content{
	width:390px;
	display:block;
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_fg.png);
	line-height: 1.5em;
	margin:0;
	padding:0 30px 2em;
}

#content p, #content i, #content div{
	margin: 0 0 1em;
	display: block;
}
#content p.note{
	font-weight:bold;
}