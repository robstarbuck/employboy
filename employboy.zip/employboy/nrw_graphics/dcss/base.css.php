
/* JAVASCRIPT DISABLED */

/* General */

* {
	font-family: verdana;
	font-size: 8pt;
	color:<?php print($colors->copy) ?>;
	background-color:none;
	white-space:normal;
}
body{
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bg.png);
	background-repeat:repeat;
	padding:1.5em;
	margin:0;
}

body.splash{
	overflow:hidden;
}


img{
	display:block;
}


div#boxfull{
	display:block;
	position:inherit;
	margin:0;
	padding:0;
}


div#boxscn{
	display:block;
	position:inherit;
	margin:0;
	padding:0;
	width:450px;
	background-image:url(<?php print($colors->imagedirectory)?>_effiback.png);
	background-position:-500px -500px;
}


div#effihold, div#effi{
	width:0;
	display:none;
}


div#effihold{
	position:absolute;
	left:50px;
	top:50px;
	height:710px;
	width:563px;
	background-image:url(<?php print($colors->imagedirectory)?>_effiback.png);
	background-color:<?php print($colors->select) ?>;
}


div#effi{
	position:absolute;
	left:50px;
	top: 50px;
	height:650px;
	width:503px;
	background-image:url(<?php print($colors->imagedirectory)?>_effi.png);
	cursor:pointer;
}


div#pane{
	display:block;
	overflow:hidden;
	width:450px;
}

div#paneind{
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bs.png);
	height:4px;
	font-size:0;
	cursor:default;
}

div#paneind.active{
	background-image:url(<?php print($colors->imagedirectory)?>_pane_base.png);
	cursor:pointer;
}

div#box{
	position:relative;
	left:0;
	margin:0;
	padding:0;
	width:450px;
}
div#content{
	width:390px;
	display:block;
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bs.png);
	line-height: 1.5em;
	margin:0;
	padding:0 30px 2em;
}

#content p, #content i, #content div{
	margin: 0 0 1em;
	display: block;
}
#content p.note{
	font-weight:bold;
}
#content .highlight{
	font-weight:bold;
	color:<?php print($colors->alert)?>;
}

#content div.link{
	background-color:<?php print($colors->copyh1) ?>;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	padding:0.25em;
}
#content div.link strong,div.link a{
	color:<?php print($colors->base) ?>;
}

div#top{
	background-image:url(<?php print($colors->imagedirectory)?>_rnd_tp.png);
	height:17px;
}
div#btm{
	background-image:url(<?php print($colors->imagedirectory)?>_rnd_bt.png);
	height:17px;
}
div#head{
	height:120px;
	margin:0;
	padding:0;
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bs.png);
	position:relative;
}
div#title{
	background-image:url(<?php print($colors->imagedirectory)?>_ebtle.png);
	background-position:30px bottom;
	background-repeat:no-repeat;
	height:65px;
	position:relative;
	margin:0 0 1em;
}
div#menuhold{
	width:390px;
	position:absolute;
	bottom:20px;
	left:30px;
}
ul#menu{
	font-size:110%;
	font-weight:bold;
	display:block;
	padding:0;
	margin:0;
	line-height:2em;
}
ul#menu li{
	margin:0 1em 0 0;
	padding:0;
	display:inline;
}
ul#menu a{
	font-size:10pt;
	text-decoration:none;
	outline:none;
	color:<?php print($colors->copy)?>;
}
ul#menu a.home{
	background-image:url(<?php print($colors->imagedirectory)?>_icon_home.gif);
	background-repeat:no-repeat;
	background-position:center left;
	padding-left:1.25em;
}

ul#menu a.selected{
	color:<?php print($colors->copyh1)?>;
	cursor:default;
}

div#menuhold #underline{
	height:3px;
	background-color:<?php print($colors->copy) ?>;
	font-size:0;
}

div#menuhold #loadhold{
	float:right;
	background-image:url(<?php print($colors->imagedirectory)?>_down.gif);
	background-repeat:no-repeat;
	height:2em;
	font-size:110%;
	width:9px;
	background-position:right center;
	font-weight:bold;
}
div#foot{
	padding: 16px 30px 20px;
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bs.png);
	margin:0;
}

div#footmenu{
	-moz-border-radius: 5px;
	-webkit-border-radius: 5px;
	border-radius: 5px;
	margin:0;
	padding:3px 0;
	height:2.5em;
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_fg.png);
}

div#footmenu.over{
	background-color:<?php print($colors->select)?>;
}

div#footmenu div#ftcon{
	padding:0 0.5em;
	color:white;
	text-align:right;
}

div.clearbasediv{
	height:1px;
	width:100%;
	clear:both;
	font-size:0;
}