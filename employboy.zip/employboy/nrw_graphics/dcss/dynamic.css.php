/* JAVASCRIPT DISABLED */

/* General */

* {
	color:<?php print($colors->copy) ?>;
}
body{
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bg.png);
}
div#boxscn{
	background-image:url(<?php print($colors->imagedirectory)?>_effiback.png);
}
div#effihold{
	background-image:url(<?php print($colors->imagedirectory)?>_effiback.png);
	background-color:<?php print($colors->select) ?>;
}
div#effi{
	background-image:url(<?php print($colors->imagedirectory)?>_effi.png);
}
div#paneind{
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bs.png);
}
div#paneind.active{
	background-image:url(<?php print($colors->imagedirectory)?>_pane_base.png);
}
div#content{
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bs.png);
}
div#top{
	background-image:url(<?php print($colors->imagedirectory)?>_rnd_tp.png);
}
div#btm{
	background-image:url(<?php print($colors->imagedirectory)?>_rnd_bt.png);
}
div#head{
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bs.png);
}
div#title{
	background-image:url(<?php print($colors->imagedirectory)?>_ebtle.png);
}
ul#menu a{
	color:<?php print($colors->copy)?>;
}
ul#menu a.home{
	background-image:url(<?php print($colors->imagedirectory)?>_icon_home.gif);
}
ul#menu a.selected{
	color:<?php print($colors->copyh1)?>;
}
div#menuhold #underline{
	background-color:<?php print($colors->copy) ?>;
}
div#menuhold #loadhold{
	background-image:url(<?php print($colors->imagedirectory)?>_down.gif);
}
div#foot{
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bs.png);
}

div#footmenu{
	background-image:url(<?php print($colors->imagedirectory)?>_onepx_fg.png);
}

div#footmenu.over{
	background-color:<?php print($colors->select)?>;
}
div#ftrndtp{
	background-image:url(<?php print($colors->imagedirectory)?>_ftrndtp.png);
}
div#ftrndbt{
	background-image:url(<?php print($colors->imagedirectory)?>_ftrndbt.png);
}


/* FORMS */
div.invalid{
	border-color:<?php print($colors->highlight) ?>;
}
label span{
	font-style:italic;
	color:<?php print($colors->alert)?>;
}
button{
	color:<?php print($colors->base)?>;
}
button.inactive{
	color:<?php print($colors->select)?>;
}
div.alphakey{
	background-image:url(<?php print($colors->imagedirectory)?>_alpha.gif);
}
#content div.outerhold{
	background-color:<?php print($colors->copy) ?>;
}
#content div.outerhold.dmargin{
	margin:0 0 2em 0 !important;
}
#content div.innerhold{
	background-color:<?php print($colors->basel2) ?>;
}
#content div.linehold div.checkhold{
	background-color:<?php print($colors->copyl1) ?>;
}
#content div.outerhold.invalid{
	background-color:<?php print($colors->select)?>;
}
#content div.focus{
	background-color:<?php print($colors->copyl1) ?>;
}
div.alert{
	background-color:<?php print($colors->highlight)?>;
	border:1px solid <?php print($colors->highlightl1)?>;
	color:<?php print($colors->copy) ?>;
}
div.notify{
	background-color:<?php print($colors->alert)?>;
	border:1px solid <?php print($colors->alertl1)?>;
	color:<?php print($colors->base) ?>;
}
div.alert span{
	color:<?php print($colors->base) ?>;
}
#content div.focus div.innerhold{
	background-image:url(<?php print($colors->imagedirectory)?>_inparrow.gif);
	border-color:<?php print($colors->select)?>;
	background-color:<?php print($colors->basel1)?>;
}