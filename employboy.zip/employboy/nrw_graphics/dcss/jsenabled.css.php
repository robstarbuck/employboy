/*JAVASCRIPT ENABLED*/

body#max{
	overflow:hidden;
	padding:0;
	margin:0;
}

#max.splash div#boxfull{
	display:none;
}
#max div#boxfull{
	display:block;
	height:630px;
	left:0;
	margin:0 0 0 120px; 
	position:absolute;
	top:0;
	overflow:hidden;
	width:700px;
}
#max div#boxscn{
	display:block;
	height:630px;
	background-image:url(<?php print($colors->imagedirectory)?>_cite.png);
	background-position:0 0;
	background-repeat:no-repeat;
	overflow:hidden;
	position:relative;
	width:700px;
}
#max #effihold, #max #effi{
	display:block;
}
#max div#effihold{
	position:absolute;
	left:50px;
	top:50px;
	height:710px;
	width:563px;
}
#max div#effi{
	position:absolute;
	left:50px;
	top: 50px;
	height:650px;
	width:503px;
	background-image:url(<?php print($colors->imagedirectory)?>_effi.png);
	cursor:pointer;
}
#max div#pane{
   	background-image:url(<?php print($colors->imagedirectory)?>_onepx_bs.png);
	display:block;
	height:400px;
	overflow: auto;
	position: absolute; 
	top: 0px; 
	width:450px;
}
#max div#box{
	display:block;
	left:197px;
	position:absolute;
	width:450px;
}