*::selection {
	background:<?php print($colors->highlight) ?>;
	color:<?php print($colors->copy) ?>;
}

*::-moz-selection {
	background:<?php print($colors->highlight) ?>;
	color:<?php print($colors->copy) ?>;
}

*::-webkit-selection {
	background:<?php print($colors->highlight) ?>;
	color:<?php print($colors->copy) ?>;
}
