/* CV SPECIFIC */

#content h5 span,#content h5 i{
	float: right;
}
#content p span {
	font-style: italic;
}
#content ul {
	list-style: none;
	padding: 0;
	margin: 0;
}
#content h1{
	font-size:16pt;
}
#content h2{
	font-size:8pt;
}
#content h3{
	font-size:8pt;
}
#content h4{
	font-size:8pt;
}
#content h5{
	font-size:8pt;
}

#content h1, #content h2, #content h3, #content h4, #content h5{
	margin: 0 0 0.5em;
}