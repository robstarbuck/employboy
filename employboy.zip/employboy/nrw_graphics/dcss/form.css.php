		/* FORMS */
		form{
			margin:0;padding:0;
		}
		div.invalid{
			border-color:<?php print($colors->highlight) ?>;
		}
		.form input{
			line-height:1.5em;
			padding:0;
			margin:0;
		}
		.innerhold input,.innerhold textarea{
			outline:none;
			background-color:transparent;
			width:380px;
			border:0;
			overflow:hidden;
		}
		textarea{
			line-height:1.5em;
			margin:0;
			padding:0;
			resize: none;
		}
		label{
			display:block;
			font-weight:bold;
			margin:0 0 0.5em;
		}
		label span{
			font-style:italic;
			color:<?php print($colors->alert)?>;
		}
		label.check{
			display:inline;
			margin:0 0.25em 0 0;
			line-height:19px;
			padding:0;
		}
		button{
		    width:auto;
		    margin:0;
    		overflow:visible;
			padding:0 0.5em;
			height:2.5em;
			background:transparent;
			border:0;
			font-weight:bold;
			cursor:pointer;
			color:<?php print($colors->base)?>;
		}
		button.inactive{
			color:<?php print($colors->select)?>;
		}
		#codehold{
			height:2.5em;
		}
		
		div.alphakey{
			font-size:0;
			float:left;
			background-image:url(<?php print($colors->imagedirectory)?>_alpha.gif);
			background-repeat:no-repeat;
			background-position:0 0;
			height:12px;
			width:10px;
		}
			
		#content div.outerhold{
			display:block;
			background-color:<?php print($colors->copy) ?>;
			display:block;
			padding:3px;
			-moz-border-radius: 3px;
			-webkit-border-radius: 3px;
			border-radius: 3px;
			margin:0 0 0.5em 0;
		}
		#content div.outerhold.dmargin{
			margin:0 0 2em 0 !important;
		}
		#content div.innerhold{
			-moz-border-radius: 0px;
			display:block;
			background-color:<?php print($colors->basel2) ?>;
			margin:0;
			height:1.6em;
			padding:0.25em 0.25em 0
		}
		#content div.texthold{
			padding:0 0.25em;
		}
		#content div.texthold, textarea{
			height:15em;
		}
		#content div.linehold div.checkhold{
			background-color:<?php print($colors->copyl1) ?>;
			height:19px;
			width:19px;
			float:right;
			-moz-border-radius: 3px;
			-webkit-border-radius: 3px;
			border-radius: 3px;
			margin:0;
		}
		#content div.linehold{
			margin:0 0 1em;
			text-align:right;
		}
		#content div.outerhold.invalid{
			background-color:<?php print($colors->select)?>;
		}
		#content div.focus{
			background-color:<?php print($colors->copyl1) ?>;
		}
		
		div.alert,div.notify,div.process{
			-moz-border-radius: 3px;
			-webkit-border-radius: 3px;
			border-radius: 3px;
			padding:0.4em;
			font-weight:bold;
		}
		div.process{
			background-color:<?php print($colors->copyh1)?>;
			border:1px solid <?php print($colors->copyh2)?>;
			color:<?php print($colors->base) ?>;
		}
		div.alert{
			background-color:<?php print($colors->highlight)?>;
			border:1px solid <?php print($colors->highlightl1)?>;
			color:<?php print($colors->copy) ?>;
		}
		div.notify{
			background-color:<?php print($colors->alert)?>;
			border:1px solid <?php print($colors->alertl1)?>;
			color:<?php print($colors->base) ?>;
		}
		div.alert span{
			font-weight:bold;
			font-style:italic;
			color:<?php print($colors->base) ?>;
		}
		#content div.focus div.innerhold{
			background-image:url(<?php print($colors->imagedirectory)?>_inparrow.gif);
			background-position:right center;
			background-repeat:no-repeat;
			border-color:<?php print($colors->select)?>;
			background-color:<?php print($colors->basel1)?>;
		}
		#maybecanedit{
		display:none;
		}