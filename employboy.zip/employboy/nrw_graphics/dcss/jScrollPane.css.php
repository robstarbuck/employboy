
.jScrollPaneContainer {
	position: relative;
	overflow: hidden;
	z-index: 1;
}

.jScrollPaneTrack {
	position: absolute;
	cursor: pointer;
	right: 0;
	top: 0;
	height: 100%;
	background-image: url(<?php print($colors->imagedirectory)?>_onepx_bg.png);
	
}
.jScrollPaneDrag {
	position: absolute;
	background: url(colorscheme/<?php print($colors->scheme) ?>/images/scroll/<?php print($colors->scheme) ?>_scr_03.png);
	background-repeat:no-repeat;
	background-position:-15px 11px;
	cursor: pointer;
	overflow: hidden;
}
.jScrollPaneDragTop {
	position: absolute;
	top: 0;
	left: 0;
	overflow: hidden;
	height:11px;
	background: url(colorscheme/<?php print($colors->scheme) ?>/images/scroll/<?php print($colors->scheme) ?>_scr_02.png);
	background-position:-15px 0px;
}
.jScrollPaneDragBottom {
	position: absolute;
	bottom: 0;
	left: 0;
	overflow: hidden;
	height:11px;
	background: url(colorscheme/<?php print($colors->scheme) ?>/images/scroll/<?php print($colors->scheme) ?>_scr_04.png);
	background-position:-15px 0px;
}
a.jScrollArrowUp {
	display: block;
	position: absolute;
	z-index: 1;
	top: 0;
	right: 0;
	text-indent: -2000px;
	overflow: hidden;
	background: url(colorscheme/<?php print($colors->scheme) ?>/images/scroll/<?php print($colors->scheme) ?>_scr_01.png);
	background-position:-15px 0px;
	height: 29px;
}
a.jScrollArrowUp:hover {
	/*background-color: #f60;*/
}

a.jScrollArrowDown {
	display: block;
	position: absolute;
	z-index: 1;
	bottom: 0;
	right: 0;
	text-indent: -2000px;
	overflow: hidden;
	background: url(colorscheme/<?php print($colors->scheme) ?>/images/scroll/<?php print($colors->scheme) ?>_scr_05.png);
	background-position:-15px 0px;
	height: 29px;
}
a.jScrollArrowDown:hover {
	/*background-color: #f60;*/
}
a.jScrollActiveArrowButton, a.jScrollActiveArrowButton:hover {
	/*background-color: #f00;*/
}