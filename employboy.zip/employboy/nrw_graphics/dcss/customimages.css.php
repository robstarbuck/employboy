div.ptsdraws{
	background-image:url(colorscheme/<?php print($colors->scheme) ?>/images/photos/<?php print($colors->scheme) ?>_pts_draws.png);
}
div.ptsport{
	background-image:url(colorscheme/<?php print($colors->scheme) ?>/images/photos/<?php print($colors->scheme) ?>_pts_port.png);
}
div.quote_php{
	background-image:url(<?php print($colors->imagedirectory)?>_quote_php.png);
}
div.hold130{
	background-position:center center;
	background-repeat:no-repeat;
	width:152px;
	height:195px;
	border:1px solid <?php print($colors->copyh2)?>;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
}


#content .imglft{
	margin:0 8px 8px 0;
	float:left;
}

#content .imgrgt{
	clear:right;
	margin:0 0 8px 8px;
	float:right;
}

#content div.img152{
	background-position:center center;
	-moz-border-radius: 3px;
	-webkit-border-radius: 3px;
	border-radius: 3px;
	width:152px;
	height:59px;
	background-repeat:no-repeat;
	margin-bottom:0px;
}