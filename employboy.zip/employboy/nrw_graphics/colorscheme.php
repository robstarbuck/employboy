<?php 
	class colorScheme{
		private $schdirectory = '../nrw_graphics/colorsetting/';
		private $imgdirectory = '../nrw_graphics/colorscheme/';
		public $defscheme = 'royalblue';
		public $colconfig;
		public $scheme;
		public $imagedirectory;
		function __construct(){
			//If the pseudo-environment is set get the scheme setting from there
			if(getenv('EB_ENVIRONMENT') != FALSE){
				$this->schdirectory = $this->schdirectory.getenv('EB_ENVIRONMENT').'/';
			}
			else{
				$this->schdirectory = $this->schdirectory.'default/';
			}


			//get the file out of the scheme directory and determine it's name
			$this->scheme  = glob($this->schdirectory.'*');

			if(count($this->scheme)){
				$this->scheme  = $this->scheme[0];
				
				//remove the directory reference to give us just the file name 
				$this->scheme = substr($this->scheme,strlen($this->schdirectory));
				
				//if this isn't a directory then give us the default
				if(!is_dir($this->imgdirectory.$this->scheme)){
					$this->scheme = $this->defscheme;
				}
			}
			else{
				$this->scheme = $this->defscheme;
			}
			
			
			//Set defaults for the colorscheme
			$this->base = 'rgb(242,242,242)';
			$this->copy = 'rgb(3,14,26)';
			$this->select = 'rgb(0,80,160)';
			$this->highlight = 'rgb(255,212,0)';
			$this->alert = 'rgb(0,80,160)';
			
			//get our colorscheme out of the xml
			//error surpress the directory read
			$colconfig = @simplexml_load_file("../nrw_graphics/colorscheme/{$this->scheme}/colconfig.xml");
			
			//if the read was successful then we'll know it's an instance of SimpleXMLElement else give us the default 
			if($this->scheme !== $this->defscheme && $colconfig instanceof SimpleXMLElement){
				foreach($colconfig -> children() as $name => $node){ 
					$this->$name = trim($node);
				}
			}
			else{
				$this->scheme = $this->defscheme;
			}
			
			$this->imagedirectory = "colorscheme/{$this->scheme}/images/{$this->scheme}";
			
			//Once the colorscheme's been established we can use the get tone function for shades and tones			
			$this->copyh1 = $this->getTone($this->copy,40);
			$this->copyh2 = $this->getTone($this->copy,80);
			$this->copyl1 = $this->getTone($this->copy,-40);
			$this->copyl2 = $this->getTone($this->copy,-80);
			
			$this->basel1 = $this->getTone($this->base,-2);
			$this->basel2 = $this->getTone($this->base,-10);
			$this->basel3 = $this->getTone($this->base,-20);
			$this->basel4 = $this->getTone($this->base,-30);

			$this->alertl1 = $this->getTone($this->alert,-20);
			$this->highlightl1 = $this->getTone($this->highlight,-20);
			
		}
		private function getTone($color,$adjustment){
			//Extract the numerics from the rgb value
			preg_match('/[0-9]{1,3},[0-9]{1,3},[0-9]{1,3}/',$color,$matches);
			$rgbarray = explode(",",$matches[0]);
			
			//Loop through the three colors and recalculate their value based on the percentage adjustment
			foreach($rgbarray as $key=>$color){
				//If it's zero it can't be adjusted
				if($color == 0){
					$rgbarray[$key] = 0;
				}
				else{
					//Work out if we're lightening or darkening
					if($adjustment < 0){
						$gap = $color;
					}
					else{
						$gap = 255 - $color;
					}
					//calcultate amount based on percentage
					$ammount = round(($gap / 100) * $adjustment);
					
					$processedcol = $color + $ammount;
					
					//ensure the value is parameterised 
					if($processedcol > 255)
					{
						$processedcol = 255;
					}
					else if($processedcol < 0)
					{
						$processedcol = 0;
					}
					
					$rgbarray[$key] = $processedcol;
				}
			}
			return 'rgb('.implode(',',$rgbarray).')';
		}
	}
?>
