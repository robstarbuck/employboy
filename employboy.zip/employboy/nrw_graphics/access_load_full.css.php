<?php
	header('Content-type: text/css');
	require_once('./colorscheme.php');
	$colors = new colorScheme();
	require_once('./dcss/jScrollPane.css.php');
	require_once('./dcss/cv.css.php');
	require_once('./dcss/form.css.php');
	require_once('./dcss/jsenabled.css.php');
	require_once('./dcss/highlight.css.php');
	require_once('./dcss/base.css.php');
	require_once('./dcss/customimages.css.php');
?>