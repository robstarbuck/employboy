<?php
	header('Content-type: text/javascript');
	require_once('../nrw_graphics/colorscheme.php');
    $colors = new colorScheme();
	$comment = '';    	
?>
//<?php echo getcwd()?>

//trigger passes in a colorscheme object to our main js file
//As well as the value from a get request to determine whether or not to hit the splash screen.
$(window).load(function(){
	var colors = {
		highlight:"<?php print($colors->highlight) ?>",
		select:"<?php print($colors->select)?>",
		copy:"<?php print($colors->copy)?>"
	};
	<?php
		$splash = '';
		if(isset($_GET["splash"]) && $_GET["splash"] !== ''){
			if($_GET["splash"] == 'true' || $_GET["splash"] == 'false'){
				$splash = $_GET["splash"];
			}
		}
	?>
	var splash = '<?php print($splash)?>';
	
	<?php print($comment)?>eb_score.ebinit(colors,splash);
})