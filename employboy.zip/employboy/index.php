<?php
	error_reporting(E_ALL);
ini_set('display_errors', 1);


    require_once('./nrw_php/switchboard.php');
    require_once('./nrw_php/actions.php');
    //require_once('./nrw_php/dBug.php');
    $menu = new menuSetUp($_SERVER['REQUEST_URI'],'.');
    $action = new execute($menu->page);
	//new dBug($action);
    $output = new pageOutput($_SERVER['REQUEST_URI'],'.',$action->exeobj);
    $footeroutput = new htmlFooter($_SERVER['REQUEST_URI'],'.');
	$splash = '';
	if(isset($_GET['skip'])){
		$splash = $_GET['skip'];
	}
	$startcmnt = "";
	$endcmnt = "";
	if(!array_key_exists('JSENABLE',$_SERVER)){
		$startcmnt = "<!--";
		$endcmnt = "-->";
	}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="google-site-verification" content="-aUyHT7NuWNC8YBIeGYiU-Cu5LEpbMZTHzJZ1PtEoYA" />
	<title>Employboy/<?php print($menu->page) ?></title>
	<link rel="Shortcut Icon" href="/<?php print($output->environment)?>.ico.ico" />
	<link rel="stylesheet" type="text/css" href="nrw_graphics/access_load_full.css.php" />
	<?php if(array_key_exists('JSENABLE',$_SERVER)): ?>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
		<script src="nrw_jquery/jquery.mousewheel.js" type="text/javascript"></script>
		<script src="nrw_jquery/jquery.em.js" type="text/javascript"></script>
		<script src="nrw_jquery/jScrollPane-1.2.3.mod.js" type="text/javascript"></script>
		<script src="nrw_jquery/jquery.ifixpng.js" type="text/javascript"></script>
		<script src="nrw_jquery/jquery.cookie.js" type="text/javascript"></script>
		<script src="nrw_jquery/jquery.color.js" type="text/javascript"></script>
		<script src="nrw_javascript/bindifs.js" type="text/javascript"></script>
		<script src="nrw_javascript/<?php print($output->environment)?>.score.js" type="text/javascript"></script>
		<script src="nrw_javascript/<?php print($output->environment)?>.pageswitch.js" type="text/javascript"></script>
		<script src="nrw_javascript/access_trigger.score.js.php?splash=<?php print($splash)?>" type="text/javascript"></script>
	<?php endif;?>
	<script type="text/javascript">
	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-18083973-1']);
	  _gaq.push(['_setDomainName', '.employboy.com']);
	  _gaq.push(['_trackPageview']);
	
	  (function() {
	    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
	    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
	    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();
	</script>
<!-- 
<?php
	if(getenv('EB_ENVIRONMENT') != FALSE){
		@include_once('./nrw_comments/'.getenv('EB_ENVIRONMENT').'.include.txt');
	}
?>
-->
</head>
    <body>
    	<div id="effihold">
		</div>
		<div id="effi">
		</div>
    		<div id="boxfull">
    			<div id="boxscn">
			    	<div id="box">
			    		<div id="top"></div>
			    		<div id="head">
			    			<div id="title"></div>
			    			<div id="menuhold">
					    		<?php $menu->printMenu()?>
					    		<div id="underline"></div>
			    			</div>
			    		</div>
			    		<form id="<?php print($menu->page) ?>" method="post" action="<?php print($menu->page) ?>">
				    		<div id="pane">
								<?php $output->requireContents()?>
							</div>
							<div id="paneind"></div>
							<div id="foot">
								<div id="footmenu">
									<div id="ftcon">
										<?php $footeroutput->printFooter() ?>
									</div>
								</div>
							</div>
					    	<div id="btm"></div>
			    		</form>
			    	</div>
		    	</div>
		    </div>
	</body>
</html>