<?php 
	require_once('./nrw_php/switchboard.php');
	$menu = new menuSetUp($_SERVER['REQUEST_URI'],'.');
	class errorHandle{
		private $error = '';
		private $error_message = '';
		public $error_array = array(
			403 => 'The request was unauthorized.',
			404 => 'No page was found at this address.'
		);
		function __construct(){
			if(getenv('ERRORCODE') != FALSE){
				$this->error = getenv('ERRORCODE');
			}
			if($this->error != ''){
				if(array_key_exists($this->error,$this->error_array)){
					$this->error_message = $this->error_array[$this->error];
				}
			}
		}
		function print_error_code(){
			print($this->error);
		}
		function print_error_message(){
			print('<p>'.$this->error_message.'</p>');
		}
	}
	$errorobj = new errorHandle();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<title>EMPLOYBOY: Error <?php $errorobj->print_error_code()?></title>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" type="text/css" href="nrw_graphics/access_load_error.css.php" />
	<script src="nrw_jquery/jquery-1.4.min.js" type="text/javascript"></script>
	<script src="nrw_jquery/jquery.ifixpng.js" type="text/javascript"></script>
    <script type="text/javascript">
    	$(window).load(function(){
			$("#top,#btm").ifixpng();
		})
    </script>
</head>
<body id="error" style="background-color:#FFF;">
<div id="errorcen">
	<div id="box">
	    <div id="top"></div>
	    <div id="head">
	    	<div id="title"></div>
	    </div>
	    <div id="content">
	    	<h1>ERROR <?php $errorobj->print_error_code()?></h1>
	    	<?php $errorobj->print_error_message()?>
	    	<div id="menuhold">
	    		<div id="underline"></div>
	    		<?php $menu->printMenu()?>
	    	</div>
	    </div>
	   	<div id="btm"></div>
	</div>
</div>
</body>
</html>
