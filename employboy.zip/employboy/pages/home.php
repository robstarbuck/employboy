<div id="content">
	<div>

		<h5>PAPER-JS FOR LAUGHS</h5>
		<p>
			<strong>01/01/2014</strong> - I've been having a play-around with PaperJS of recent and ended up producing this Facebook app. Works with IE9+ and integrates Workers wherever the browser supports it. Still in BETA but I should have the finished product out soon.
		</p>
		<p>Happy New Year</p>
		<p><a href="http://fb.ouinon.co/popularity/" title="Certificate of Popularity" target="_blank">Certificate of Popularity</a></p>
	
		<h5>HTML 5</h5>
		<p>
			<strong>22/09/2013</strong> - Just a little note to say that my website is now running HTML5, it was designed to be 'futureproof' a bit like Andie Macdowell so I thought it time.
		</p>
		<p>
			A redesign is on the cards.
		</p>
	
	
		<h5>FLYING SOLO</h5>
		<p>
			<strong>08/07/2013</strong> - Today was the first day that I've ever worked for myself. It was a really productive day, here's hoping it was the first of many. Masterlessness is a good way to be.
		</p>
	
		<h5>FAREWELL OLD JOB (AGAIN)</h5>
		<p>
			<strong>04/07/2013</strong> - Last week saw me regretfully leaving the company I have known and loved for nearly three years, <a href="http://www.ycoyacht.com/" title="Y.CO - The Yacht Company.">Y.CO</a>. I really enjoyed my time there, likely to be the best company I'll ever work for directly. All my best wishes to the team there.
		</p>
		<p>
			Please accept this bit of SEO as a parting gift, well you always were the
			best charter brokers for <a href="http://www.ycoyacht.com/story/yacht-sales/" title="Luxury Yacht Sales">Luxury Yacht Sales</a>. Ciao guys.
		</p>
	
		<h5>FAREWELL OLD JOB</h5>
		<p>
			<strong>15/10/2010</strong> - Today saw me leave my old job at acquire. I’m leaving with a lot of good memories as well as an overly generous parting gift from my colleagues. A massive thanks to all the grafters at Skipton for all their help over the years. Sincerely - I’m going to miss you. Robert (well it was going to be wasn’t it).
		</p>
		<!--
		<h5>NEW EMPLOYMENT!</h5>
		<p>Hello friends and prospective employers. Thank you for visiting my website, it's purpose however has been annulled as I have found a new job with new employers. I'll be saying farewell to a lot of things. I'll have all the details when I'm sat at my new desk but in the meantime it's too soon to give out details so you'll have to wait. <i>Robert.</i></p>
		<h5>INTRODUCTION</h5>
			<div class="quote_php img152 imgrgt">
			</div>
			<p>
				It's done, much talk and a bit of effort later and employboy.com is finally complete and so begins my search for another job. Basically this site's purpose is to find work for me. I am looking for a job as a PHP developer, if you can offer that then please read on as I hope to interest you. 
			</p>
		-->
		<h5>ABOUT THIS SITE</h5>
		<p>
			This site was put together using Apache, PHP, jQuery and a few plugins. PS and Illustrator were used for all the designs. It incorporates AJAX,AJAH and AJAJ really and there's even a bit where I use just JAJ. Most page calls are redirected to index.php and a page snippet from a subdirectory is included or if you're using in page navigation an AJAH request returns the same snippet. The site's color scheme is loaded through an xml file which also cites the directory for the images. The images themselves are really just templates before a photoshop batch process saves them with a color scheme, it means you can create an entirely new color-scheme in no time at all. Another thing I'd like to draw your attention to is the resizeability. The site works for browsers with insufficient screen sizes and those without JS in the same way, producing the static version of the site - this is viewable by shrinking the window down below 800 x 530. After some toil, the site does I'm pleased to say work in IE6, I know you share my pain. This site's JS has been minified but if you'd like to read through it all with comments you can do so at - <a href="http://dev.employboy.com" target="_blank">dev.employboy.com</a>.
		</p>
		<h5>
			LIFE AND CAREER SO FAR
		</h5>
		<div class="ptsdraws hold130 imgrgt">
		</div>
		<div class="ptsport hold130 imgrgt">
		</div>
		<p>
		I was born in Yorkshire to an Armenian mother and a father from Nottinghamshire, if you're wondering where Armenia is then you wouldn't be the first. Just like Nelson Mandela, Robert DeNiro and John Lennon I too am an only child.
		</p>
		<p>
		So to fast track to something more relevant, I had an interest in computer graphics way back in secondary school. Sixth form offered few of the facilities I needed to hone my talent so I opted for College and Design and Technology. All of this was back in the days when a bit of rotoscope and a Gaussian blurred background could really wow a lecturer. I felt myself a bit of a prodigal child in my College days and I did well, despite my photography lecturer neglectfully destroying two months of my work. Had I had my time again I think I probably should have just gone straight into work after College as technically I was ready for it but I don't think I'd have become a developer if I had. I did instead go on to the University of Sunderland to do Electronic Media Design, I was to my credit fast tracked to the second year but was too young to know what was good for me and I repeated my last year. I was very interested in web design at this stage and despite producing a few sites I still had my heart in design.
		</p>
		<p>
		Web design became a reality when I was requested to do some freelance web development for Network Designs in Knaresborough. My problem was that I didn't understand anything about client management and many of the jobs I did back then remain unpaid. In 2007 the year of the National's album Boxer I took up employ at <a href="http://www.acquireservices.co.uk/" target="_blank">Acquire Services</a> developing the <a href="http://www.epsys.co.uk/" target="_blank">epsys</a> system. I've learnt so much from my time there and I was very fortunate to get the job, I will always be thankful to my employers at Acquire and the staff they were all very helpful and I learnt much from their tuition and patience. So without any of the enjoyable bits in between that's been my life and career so far. Where I go next may very well depend on you.
		</p>
		<!--
		<h5>
		WHAT I AM NO LONGER LOOKING FOR
		</h5>
		<p>
			I've been developing a closed site for three years and now I'd like some variety. I know that I have a great sense of design and I can produce good front-end work but I wouldn't take a job that doesn't offer the chance to develop using php. I wouldn't like to see my server-side skills put by the wayside. A reasonable salary and a friendly working environment go without saying. I think that about sums it up.
		</p>
		-->
		<div class="clearbasediv"></div>
	</div>
</div>