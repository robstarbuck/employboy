<div id="content" class="form">
	<label for="inpname" id="name_label">From: <?php $this->pass->print_error_val('name') ?></label>
	<div class="outerhold">
		<div class="innerhold">
			<input name="name" type="text" value="<?php print $this->pass->get_passed_val('name') ?>"/>
		</div>
	</div>
	
	<label for="inpemail" id="email_label">Your Email: <?php $this->pass->print_error_val('email') ?></label>
	<div class="outerhold">
		<div class="innerhold">
			<input name="email" type="text" value="<?php print $this->pass->get_passed_val('email') ?>"/>
		</div>
	</div>
	<label for="txtmessage" id="text_label">Message: <?php $this->pass->print_error_val('text') ?></label>
	<div class="outerhold dmargin">
		<div class="innerhold texthold">
			<textarea name="text" type="text" style="margin:0;padding:0;display:block;border:0;background-color:transparent;width:100%;overflow:hidden;font-size:8pt;"><?php print $this->pass->get_passed_val('text') ?></textarea>
		</div>
	</div>
	<div class="linehold right">
		<div class="checkhold">
		<input type="checkbox" name="check_cc" style="padding:0;margin:0;width:auto;height:19px;width:19px;" id="check_cc"></input>
		</div>
		<label class="check" for="check_cc">Copy to my email:</label>
	</div>
	<?php $this->pass->print_success() ?>
	<input type="hidden" name="pagetype" value="contact" />
</div>