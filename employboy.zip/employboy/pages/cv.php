<div id="content">
	<div>
		<h5>
		    CONTACT DETAILS
			<span>
				<?php echo 'Date: '. date('Y-m-d');?>
			</span>
		</h5>
		<ul>
		    <li>
		      Email: employboy@gmail.com
		    </li>
		</ul>
	</div>
	<div>
		<h5>
			CAREER OBJECTIVE
		</h5>
		<h5>
			Web Designer
		</h5>
		<p>
			Dependable web developer with wide ranging experience. Looking to knuckle down in a Full Time position with a progressive web design company developing in PHP or a similar interpretative language. &nbsp;<br>
		</p>
	</div>
	<div>
		<h5>
			EDUCATION
		</h5>
		<p>
			Harrogate Grammar School 1994 to 1999 <i> 9 GCSEs-A to C, including Maths and English </i>
		</p>
		<p>
			Harrogate Art College 1999 to 2001 <i> BTEC in Design (Communications), A level in Photography </i>
		</p>
		<p>
			University of Sunderland 2001 to 2004 <i> Honours Degree in Electronic Media Design </i>
		</p>
	</div>
	<div>
		<h5>
			SKILLS IN BRIEF
		</h5>
		<p>
		DEBIAN GNU/LINUX · APACHE + MOD_REWRITE · MYSQL · PHP · COLDFUSION · JAVASCRIPT + JQUERY · HTML · CSS
		</p>
		<h5>
			SKILLS IN FULL
		</h5>
		<p>
		I currently specialise in PHP and Coldfusion and am a keen advocate of design patterns and MVC architecture.
Accompanying my key skills is - as you would imagine - a good understanding of javascript and the jQuery library.
I generally use jQuery for any asynchronous data retrievals, I usually favour JSON (AJAJ) over XML (AJAX) as a
return type.
		</p>
		<p>
As well as my more front-end abilities, I also have a solid base understanding of Linux although Windows is still
my OS of choice. I have however set up web servers with Debian/Linux using Apache. I'm a keen user of the
mod_rewrite module and a good understanding of regular expressions has facilitated this.
My understanding of Mysql is excellent, I've written and optimised queries, views and triggers with good aptitude
as my current position has demanded.
		</p>
		<p>
Because of a background in print based media, I have developed and held onto a lot of transferable skills which
put me in good stead for a career in web design. I regularly use the Adobe Suite out of hobby (Photoshop,
Illustrator, Image Ready) and use for it crops up occasionally at work. It is from this print background that I
picked up the web basics HTML and CSS. Recently I've developed a technique for dynamic colour schemes with
Photoshop and xml.
		</p>
		<p>
I'm used to working with Revision Control software specifically CVS which is well supported in eclipse - being my
editor of choice. I am currently teaching myself how to use the ZEND Framework. 
		</p>
	</div>
	<div>
		<h5>
			WORK EXPERIENCE
		</h5>
		<h5>
			<i>August 2007 to Present</i>
			Acquire Services - Skipton North&nbsp;Yorks.
		</h5>
		<p>
		    I am deeply grateful to my present employers for the opportunity they have afforded me has served to develop my career greatly. I've worked autonomously to produce a file management system, countless financial reports and some nicely conceived administrative modules. I developed my whole understanding of query languages through the job which has had me entrusted to write some of our sites weightier queries. I also act as webmaster for the sites CMS system. I can honestly say I've never learnt so much in any other job I've taken.
		</p>
		<p><i>REFERENCE: Available on provision of work&nbsp;</i></p>
		<h5>
			<i>May 2005 to August 2007</i>
		    Network Print &amp; Design - Knaresborough, North&nbsp;Yorks.
		</h5>
		<p>
		    I was working at network prints as an employee and as a freelance web designer. The workload at the company was sporadic and I found a lot of time to develop my skill base in static web design. During my time at the company I developed a number of static sites which laid out the foundation of my career.
		</p>
	  <i>REFERENCE: Rod Hall, Network Print &amp; Design, Unit 3, Gymtec House, Whincup Avenue, Knaresborough, North Yorkshire HG5 0JH</i>
		<h5>
			<i><b>&nbsp;&nbsp;June 2006 to August 2007</b></i>
		    SkySports - Harrogate, North&nbsp;Yorks.
		</h5>
		<p>
			I acquired this work placement as a means of learning Flash Actionscript. The staff at Sky have been invaluable in bringing me up to speed with the language and it acted as a means to my introduction to Javascript. The department is always busy and I've helped out on a number of Flash projects that have gone on to be published.
		</p>
		<i> REFERENCE: Richard Quaite, Web Development Manager, SkySports, Central House, Beckwith Knowle, Otley Road, Harrogate, HG31WA </i>
	</div>
</div>