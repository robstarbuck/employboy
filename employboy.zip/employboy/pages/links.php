<?php
	$web = array(
				array(
					"title" => "Any font you want", 
					"link" => "http://code.google.com/webfonts",
					"description" => "I must curb my enthusiasm regarding the @font-face technique. As per usual google makes things easier with their API. This just changes everything."
				)
				,array(
					"title" => "Stack Overflow", 
					"link" => "http://stackoverflow.com/",
					"description" => "So often the answer to my problem sits in the forums at Stack Overflow."
				)
				,array(
					"title" => "Seb Duggan", 
					"link" => "http://sebduggan.com/posts/ie6-gzip-bug-solved-using-isapi-rewrite",
					"description" => "Seb is a real lad for posting this. It's all about gzip and ie6, boring but it got me out of a sticky spot so it feels only right to credit him."
				)
				,array(
					"title" => "IE Tester Software", 
					"link" => "http://www.my-debugbar.com/wiki/IETester/HomePage",
					"description" => "There are still a lot of Web Developers who don't know about this little gem."
				)
				,array(
					"title" => "Typetester typeface Comparisons", 
					"link" => "http://www.typetester.org/",
					"description" => "Useful for quickly chalking up a font for your site."
				)
				,array(
					"title" => "The Kevin Luck Scroller", 
					"link" => "http://www.kelvinluck.com/assets/jquery/jScrollPane/jScrollPane.html",
					"description" => "I took a look at a few jquery scrollers for my site and I thought this one best put together. I've made minor modifications to my own."
				)
				,array(
					"title" => "Best way to minify", 
					"link" => "http://andrewdupont.net/2007/02/26/packing-prototype/",
					"description" => "Useful information can be found here about how best to minify your javascript files."
				)
				,array(
					"title" => "Ask Apache, mod_rewrite tips", 
					"link" => "http://www.askapache.com/htaccess/mod_rewrite-tips-and-tricks.html",
					"description" => "When I was getting used to Apache's mod_rewrite I started with this site. It was a real eye-opener in terms of what could be achieved with the module."
				)
				,array(
					"title" => "404 Error pages", 
					"link" => "http://www.smashingmagazine.com/2007/08/17/404-error-pages-reloaded/",
					"description" => "I'm weirdly interested in 404 page design, can't understand why no-one bothers with humourous pages for 403s."
				)
				,array(
					"title" => "Web links to web links", 
					"link" => "http://www.alvit.de/handbook/",
					"description" => "This is largely useful for CSS, I've found a lot of useful tools at this site."
				)
	);
?>


<div id="content">
	<div>
		<p>
			Well you know you're really padding things out when Links is a menu item. But I love sharing things and beneath are some things I hope you find useful.
		</p>
		<p>
			For the meantime, it's just links on Web Development but I'll find time for some more recreational links as soon as I manage to sift through my bookmarks.
		</p>
		<h5>
		Web:
		</h5>
		<p>
		<?php 
		foreach($web as $key=>$value){
			$printkey = $key + 1;
			print('<div>
				<div class="link">
				<strong>'.$printkey.'.</strong><a href="'.$web[$key]["link"].'" target="_blank">'.$web[$key]["title"].'</a>
				</div>
				<p>'.$web[$key]["description"].'</p>
				</div>');
		}
		?>
		</p>
	</div>
</div>